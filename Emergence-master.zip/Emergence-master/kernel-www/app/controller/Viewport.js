Ext.define('eMan.controller.Viewport', {
	extend: 'Ext.app.Controller'

	,views: ['Viewport']

});