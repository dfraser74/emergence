Ext.define('eMan.model.Skeleton', {
	extend: 'Ext.data.Model'

	,fields: [
		{name: 'hostname', type: 'string'}
		,{name: 'key', type: 'string'}
	]
});
