Ext.define('eMan.store.Sites', {
	extend: 'Ext.data.Store'

	,model: 'eMan.model.Site'
	,autoSync: true
	,autoLoad: true
});
