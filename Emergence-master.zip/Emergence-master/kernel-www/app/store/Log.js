Ext.define('eMan.store.Log', {
	extend: 'Ext.data.Store'

	,model: 'eMan.model.LogEntry'

});