Ext.define('eMan.store.Services', {
	extend: 'Ext.data.Store'

	,model: 'eMan.model.Service'
	,autoLoad: true

});